﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace optymalizacja_funkcji
{
    using p = Problem;
    class TabooSearch
    {

        public static double Run(int maxIter, Random rand)
        {

            List<double> taboo = new List<double>();
            double max = double.MinValue;
            double x = rand.NextDouble() * 3 - 1;

            for(int i = 0; i< maxIter; i++)
            {
            if (!taboo.Contains(x))
            {
                  double y = p.Function(x);

                if(y > max)
                {
                    max = y;
                    taboo.Add(x);
                    
                }
            }
            else
            {
                Console.WriteLine("Taboo!");
            }
            }

            

            return max;
        }

    }
}
